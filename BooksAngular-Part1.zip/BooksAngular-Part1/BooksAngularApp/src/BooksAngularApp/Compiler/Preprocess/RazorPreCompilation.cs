﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNet.Mvc;

namespace BooksAngularApp.Compiler.Preprocess
{
    // Uncomment the following class to enable pre-compilation of Razor views.
    // Pre-compilation may reduce the time it takes to build and launch your project.
    // Please note, in this pre-release of Visual Studio 2015, enabling pre-compilation may cause IntelliSense and build errors in views using Tag Helpers.

    //public class RazorPreCompilation : RazorPreCompileModule
    //{
    //    public RazorPreCompilation(IServiceProvider provider) : base(provider)
    //    {
    //        GenerateSymbols = true;
    //    }
    //}
}
