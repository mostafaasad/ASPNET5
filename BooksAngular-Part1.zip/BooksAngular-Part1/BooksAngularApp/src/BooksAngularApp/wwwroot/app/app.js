(function () {
    'use strict';

    angular.module('booksApp', ['booksServices']);
})();